
class AppDimensions {
  static const double padding = 16.0;
  static const double cardElevation = 6.0;
  static const double borderRadius = 12.0;
}

   const double paddingLarge = 24.0;
